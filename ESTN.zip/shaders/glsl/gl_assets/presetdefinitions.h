// Welcome to the Preset Dashboard 1.5! Here is where you can make changes
// to the shader pack like torch color and shadow color to however you like!
// The functions here should be understandable here so you won't get confused,
// if you have suggestions on improving the instructions, tell me on Discord!

// Torch color (The values here are low because adding color tint to torches looks weird, but you can change it)
vec3 ESTN1_TORCH_COLOR = vec3(0.2, 0.1, 0.0);
// The higher the value, the more the light of the torch expands, same goes for lower values
float torchThreshold = 0.75;
float torchBrightness = 2.0;

// Entity emissive brightness color
float emissiveValue = 2.0;

// Shadow Color
vec3 ESTN1_SHADOW_COLOR = vec3(0.1, 0.16, 0.64);

// Tonemap settings, anything higher than 2.0 means you're crazy enough to destroy your phone :D
float saturation = 1.5;
float brightness = 1.25;
float exposure = 1.0;
float contrast = 1.0;

// Change the sky color here
vec4 d_color = vec4(0.2, 0.7, 1.2, 1.0); // Day
vec4 n_color = vec4(0.0, 0.4, 0.8, 1.0); // Night
vec4 s_color = vec4(0.4, 0.0, 1.2, 1.0); // Sunset and sunrise

// Sky threshold
float skyMax = 0.64;
float skyMin = 0.1;

// Here are the additional pack settings, disable any of these features if your phone can't handle the computation

// You can disable any of these features by adding "//" before the #define to disable the feature (ex. //#define FEATURE)
#define PLANT_WAVES
#define WATER_WAVES
#define UNDERWATER_WAVES